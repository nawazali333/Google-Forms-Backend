import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import fs from 'fs-extra';
import path from 'path';

const app = express();
const PORT = 3000;
const dbPath = path.join(__dirname, 'db.json');

// Middleware
app.use(bodyParser.json());

// Helper function to read the JSON file
const readDB = async () => {
    try {
        const data = await fs.readFile(dbPath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading the database file:', error);
        return [];
    }
};

// Helper function to write to the JSON file
const writeDB = async (data: any) => {
    try {
        await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
        console.error('Error writing to the database file:', error);
    }
};

// Ping endpoint
app.get('/ping', (req: Request, res: Response) => {
    res.send(true);
});

// Submit endpoint
app.post('/submit', async (req: Request, res: Response) => {
    const { name, email, phone, github_link, stopwatch_time } = req.body;

    if (!name || !email || !phone || !github_link || !stopwatch_time) {
        return res.status(400).send('All fields are required.');
    }

    const newSubmission = { name, email, phone, github_link, stopwatch_time };
    const submissions = await readDB();
    submissions.push(newSubmission);
    await writeDB(submissions);

    res.send('Submission successful');
});

// Read endpoint
app.get('/read', async (req: Request, res: Response) => {
    const index = parseInt(req.query.index as string);

    if (isNaN(index) || index < 0) {
        return res.status(400).send('Invalid index.');
    }

    const submissions = await readDB();

    if (index >= submissions.length) {
        return res.status(404).send('Submission not found.');
    }

    res.json(submissions[index]);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
